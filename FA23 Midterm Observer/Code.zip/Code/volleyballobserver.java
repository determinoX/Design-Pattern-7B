public class volleyballobserver {
    void updatevolleyballobserver(String sport, String message);
}

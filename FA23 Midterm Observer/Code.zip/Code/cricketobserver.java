public class cricketobserver {
    void updatecricketobserver(String sport, String message);
}

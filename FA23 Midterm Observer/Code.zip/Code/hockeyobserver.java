public class hockeyobserver {
    
}

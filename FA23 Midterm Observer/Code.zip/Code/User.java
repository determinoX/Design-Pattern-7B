public class User implements subscriber {
    private String name;
    public User(String name){
     this.name = name;
            
    }
    
}
